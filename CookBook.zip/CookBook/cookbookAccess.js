//By the way, this is for my login form.

    document.getElementById("loginForm").addEventListener("submit", function(event){
        event.preventDefault();

        const username = document.getElementById("username").value;
        const pass = document.getElementById("password").value;
        if(username == 'Zimmer6653' && pass == "pandorabox"){
            alert("Welcome to Cap'n Bisons!")
            window.location.href = 'Home.html'
        }else{
            alert("Wrong entry invalid")
        }
    })


    function reiPage(){
        window.location.href = "https://www.facebook.com/isyut.tuysi";
    }
   
    function  benniePage(){
        window.location.href = "https://www.facebook.com/profile.php?id=100069878760006";
    }
    
    function  puyotPage(){
        window.location.href = "https://www.facebook.com/johnmoses.puyot";
    }

    function ravensonPage(){
        window.location.href = "https://www.facebook.com/ravenson.tayong";
    }




