/**MINDANAO RECIPEEEES */

/*MINDANAO APPETIZERS*/

//Satti
let sattiIP = 1;
const sattisatti = [
   "Ingredients:<br>  <ul>   <li>500g skewered and grilled meat (beef or chicken)</li>   <li>1/4 cup soy sauce</li>   <li>2 tablespoons calamansi juice</li>   <li>3 cloves garlic, minced</li>   <li>1 cup peanut butter</li>   <li>2 cups coconut milk</li>   <li>3 tablespoons Annatto (achuete) oil</li>   <li>2 tablespoons brown sugar</li>   <li>1 tablespoon soy sauce</li>   <li>Salt and pepper to taste</li>   <li>Sliced cucumber and onions for garnish</li>      </ul>",
   "Procedures:<br>   <ol>   <li>Mix soy sauce, calamansi juice, and minced garlic.</li>    <li>Coat the meat with the marinade and let it sit for at least 30 minutes.</li>      <li>Skewer the marinated meat.</li>      <li>Grill until fully cooked, achieving a slightly charred exterior.</li>        </ol>",
   "Prepare Satti Sauce:<br> <ol>   <li>In a saucepan, combine peanut butter, coconut milk, Annatto<br> oil, brown sugar, and soy sauce.</li>     <li>Simmer over low heat, stirring continuously until well blended.</li>      <li>Season with salt and pepper to taste.</li>         </ol>",
   "Procedures(Serving):<br> <ol> <li> Arrange the grilled skewers on a plate.</li>   <li>Drizzle the Satti sauce over the skewers.</li>    <li>Garnish with sliced cucumber and onions.</li>    <li>Serve hot and enjoy this flavorful Mindanao appetizer!</li>      </ol>",
   "Please click the button to proceed,"

];

function sattiNext(){
  sattiIP = (sattiIP + 1) % sattisatti.length;
  document.getElementById("sattiIngproc").innerHTML = sattisatti[sattiIP];
}

//Pastil
let pastilIP = 1;
const pastilpastil = [
   "Ingredients:<br>  <ul>   <li>2 cups cooked rice</li>   <li>1 cup shredded chicken or beef</li>   <li>Banana leaves for wrapping</li>       </ul>",
   "Procedures:<br>   <ol>   <li>Pass banana leaves over an open flame to make them pliable.</li>    <li>Cut into 8x8 inch squares.</li>      <li>Place a portion of cooked rice in the center of a banana leaf.</li>      <li>Top with shredded chicken or beef.</li>      <li>Fold the banana leaf to form a secure packet.</li>      <li>Steam the wrapped pastil until heated through.</li>      <li>Unwrap the banana leaf and serve hot.</li>      </ol>",
   "Please click the button to proceed,"

];

function pastilNext(){
  pastilIP = (pastilIP + 1) % pastilpastil.length;
  document.getElementById("pastilIngproc").innerHTML = pastilpastil[pastilIP];
}


//Tiyula Itum

let tiyulaItumIP = 1;
const tiyulaItum = [
   "Ingredients:<br>  <ul>   <li>500g beef, cut into chunks</li>   <li>1 thumb-sized ginger, sliced</li>   <li>3 cloves garlic, minced</li>   <li>1 onion, chopped</li>   <li>Blackened coconut (burnt coconut meat)</li>   <li>1 teaspoon turmeric powder</li>   <li>2-3 chili peppers</li>   <li>Salt and pepper to taste</li>     </ul>",
   "Procedures:<br>   <ol>   <li>In a pot, sauté garlic, ginger, and onions until fragrant.</li>    <li>Add the beef chunks and brown on all sides.</li>      <li>Mix in the blackened coconut, turmeric powder, and chili peppers.</li>      <li>Pour enough water to cover the beef.</li>      <li>Season with salt and pepper</li>      <li>Simmer until the beef is tender and flavors meld.</li>        </ol>",
   "Please click the button to proceed,"

];

function tiyulaItumNext(){
  tiyulaItumIP = (tiyulaItumIP + 1) % tiyulaItum.length;
  document.getElementById("tiyulaItumIngproc").innerHTML = tiyulaItum[tiyulaItumIP];
}

//Piyanggang Manok

let piyanggangIP = 1;
const piyanggangManok = [
   "Ingredients:<br>  <ul>   <li>Chicken pieces</li>   <li>1 cup coconut milk</li>   <li>1 teaspoon turmeric powder</li>   <li>1 tablespoon minced ginger</li>   <li>3 cloves garlic, minced</li>   <li>2 shallots, sliced</li>   <li>Salt and pepper to taste</li>      </ul>",
   "Procedures:<br>   <ol>   <li>Marinate chicken with turmeric, minced ginger, garlic, and salt<br> for 30 minutes.</li>    <li>In a pan, sauté shallots until translucent.</li>      <li>Add marinated chicken and brown on all sides.</li>      <li>Pour coconut milk over the chicken.</li>      <li>Simmer until the chicken is fully cooked.</li>         </ol>",
   "Please click the button to proceed,"

];

function piyanggangManokNext(){
  piyanggangIP = (piyanggangIP + 1) % piyanggangManok.length;
  document.getElementById("piyanggangManokIngproc").innerHTML = piyanggangManok[piyanggangIP];
}

//Tuna Kinilaw
let tunaKinilawIP = 1;
const tunaKinilaw = [
   "Ingredients:<br>  <ul>   <li>500g fresh tuna, cubed</li>   <li>1 cup vinegar</li>   <li>1/2 cup coconut milk</li>   <li>1 tablespoon minced ginger</li>   <li>1 red onion, finely chopped</li>   <li>2 green chili peppers, sliced</li>   <li>Salt and pepper to taste</li>     </ul>",
   "Procedures:<br>   <ol>   <li>In a bowl, mix tuna with vinegar, ginger, and salt. Marinate for a few minutes.</li>    <li>Add coconut milk, chopped red onion, and sliced chili peppers.</li>      <li>Season with salt and pepper to taste.</li>      <li>Refrigerate for at least 15 minutes before serving.</li>            </ol>",
   "Please click the button to proceed,"

];

function tunaKinilawNext(){
  tunaKinilawIP = (tunaKinilawIP + 1) % tunaKinilaw.length;
  document.getElementById("tunaKinilawIngproc").innerHTML = tunaKinilaw[tunaKinilawIP];
}







/**MINDANAO  SALAD */

//Ulam Salad
let ulamIP = 1;
const ulamSalad = [
   "Ingredients:<br><ul>  <li>2 cups mixed greens</li>  <li>1 cup cherry tomatoes, halved</li>    <li>1 cucumber, sliced</li>    <li>1/2 red onion, thinly sliced</li>    <li>2 hard-boiled eggs, sliced</li>    <li>1 grilled chicken breast, sliced</li>    <li>Balsamic vinaigrette dressing</li>      </ul>",
   "Procedures:<br><ol>  <li>Wash and chop vegetables.</li>  <li>Grill chicken until cooked; slice.</li>    <li>Arrange greens on a plate.</li>    <li>Add tomatoes, cucumber, onion, and eggs.</li>    <li>Top with sliced grilled chicken.</li>    <li>Drizzle with balsamic vinaigrette.</li>    <li>Toss before serving.</li>     </ol>",
   "Please click the button to proceed,"
];

function ulamNext(){
  ulamIP = (ulamIP + 1) % ulamSalad.length;
  document.getElementById("ulamIngproc").innerHTML = ulamSalad[ulamIP];
}

//Ensaladong Labanos
let ensaladongLabanosIP = 1;
const ensaladongLabanos = [
   "Ingredients:<br><ul>  <li>2 labanos (radish), julienned</li>  <li>1 tomato, diced</li>    <li>2 salted duck eggs, sliced</li>    <li>1/2 red onion, thinly sliced</li>    <li>Bagoong (fermented shrimp paste)</li>    </ul>",
   "Procedures:<br><ol>  <li>Peel and julienne labanos.</li>  <li>Dice tomato; slice duck eggs and onion.</li>    <li>Mix labanos, tomato, eggs, and onion.</li>    <li>Add bagoong to taste</li>    <li>Toss ingredients.</li>    <li>Serve chilled.</li>    </ol>",
   "Please click the button to proceed,"
];

function ensaladongLabanosNext(){
  ensaladongLabanosIP = (ensaladongLabanosIP + 1) % ensaladongLabanos.length;
  document.getElementById("ensaladongLabanosIngproc").innerHTML = ensaladongLabanos[ensaladongLabanosIP];
}


//Papaya Atchara Salad
let papayaIP = 1;
const papayaAtchara = [
   "Ingredients:<br><ul>  <li>1 green papaya, shredded</li>  <li>2 carrots, julienned</li>    <li>1 red bell pepper, thinly sliced</li>    <li>1/2 cup raisins</li>    <li>1/2 cup white vinegar</li>    <li>1/4 cup sugar</li>    <li>Salt to taste</li>    </ul>",
   "Procedures:<br><ol>  <li>Peel and shred papaya; julienne carrots.</li>  <li>Mix papaya, carrots, bell pepper, and raisins.</li>    <li>Mix vinegar, sugar, and salt for dressing.</li>    <li>Pour dressing over mixture; toss.</li>    <li>Marinate for 30 mins in the refrigerator.</li>          </ol>",
   "Please click the button to proceed,"
];

function papayaAtcharaNext(){
  papayaIP = (papayaIP + 1) % papayaAtchara.length;
  document.getElementById("papayaAtcharaIngproc").innerHTML = papayaAtchara[papayaIP];
}


//Kinilaw na Masalugi
let masalugiIP = 1;
const masalugilaw = [
   "Ingredients:<br><ul>  <li>Fresh masalugi (tuna), cubed</li>  <li>1/2 cup coconut vinegar</li>    <li>1 tbsp ginger, minced</li>    <li>1/2 red onion, thinly sliced</li>    <li>1 green chili, sliced</li>    <li>Calamansi juice</li>    <li>Salt and pepper to taste</li>       </ul>",
   "Procedures:<br><ol>  <li>Combine masalugi, vinegar, ginger, onion, and chili.</li>  <li>Squeeze calamansi juice.</li>    <li>Season with salt and pepper.</li>    <li>Marinate for 15-30 mins in the refrigerator.</li>    <li>Serve chilled.</li>       </ol>",
   "Please click the button to proceed,"
];

function masalugiNext(){
  masalugiIP = (masalugiIP + 1) % masalugilaw.length;
  document.getElementById("masalugiIngproc").innerHTML = masalugilaw[masalugiIP];
}

//Pomelo Salad
let pomeloIP = 1;
const pomeloSalad = [
   "Ingredients:<br><ul>  <li>Pomelo segments</li>  <li>Shrimp, boiled and peeled</li>    <li>1 cup cherry tomatoes, halved</li>    <li>1 avocado, diced</li>    <li>Mixed greens</li>    <li>Lime vinaigrette dressing</li>    </ul>",
   "Procedures:<br><ol>  <li>Peel and segment pomelo.</li>  <li>Boil and peel shrimp.</li>    <li>Halve cherry tomatoes; dice avocado.</li>    <li>Arrange greens on a plate.</li>    <li>Add pomelo, shrimp, tomatoes, and avocado.</li>    <li>Drizzle with lime vinaigrette.</li>    <li>Toss before serving.</li>     </ol>",
   "Please click the button to proceed,"
];

function pomeloNext(){
  pomeloIP = (pomeloIP + 1) % pomeloSalad.length;
  document.getElementById("pomeloIngproc").innerHTML = pomeloSalad[pomeloIP];
}













/**MINDANAO SOUP DISHES */

//Lauya
let lauyaIP = 1;
const lalauya = [
  "Ingredients:<br><ul> <li>1 kg beef, thinly sliced</li>  <li>1 green unripe papaya, peeled, seeds removed, and sliced</li>  <li>2-3 pieces long green chili</li>  <li>2 thumbsized ginger, sliced thinly</li>  <li>1 onion, sliced</li>  <li>4 cloves garlic, minced</li>  <li>1 tablespoon fish sauce (patis)</li>  <li>Salt and pepper to taste</li>  <li>2 liters water</li>  </ul>",
  "Procedures:<br><ol>  <li>In a large pot, bring water to a boil.</li> <li>Add sliced beef and cook until tender, skimming off any impurities that rise to the surface.</li>  <li>Add ginger, garlic, and onion. Simmer until the flavors meld.</li>   <li>Season with fish sauce, salt, and pepper to taste.</li>   <li>Add sliced papaya and long green chili. Simmer until the papaya is tender.</li>   <li>Adjust seasoning if necessary.</li>   <li>Serve hot and enjoy Lauya!</li>         </ol>",
  "Please click the button to proceed,"
];

function lauyaNext(){
  lauyaIP = (lauyaIP + 1) % lalauya.length;
  document.getElementById("lauyaIngproc").innerHTML = lalauya[lauyaIP];
}

//Sinuglaw
let sinuglawIP = 1;
const sisinuglaw = [
  "Ingredients:<br><ul> <li>500g pork belly, grilled and diced</li>  <li>500g fresh tuna, cubed</li>  <li>1 cup coconut vinegar</li>  <li>1 red onion, finely sliced</li>  <li>2-3 pieces red or green chili, minced</li>  <li>1 thumb-sized ginger, minced</li>  <li>3-4 tablespoons calamansi juice</li>  <li>1 cucumber, sliced (optional)</li>        </ul>",
  "Procedures:<br><ol>  <li>In a bowl, combine grilled pork belly, fresh tuna, red onion, chili, and ginger.</li> <li>Pour coconut vinegar and calamansi juice over the mixture.</li>  <li>Season with salt and pepper. Mix well.</li>   <li>Add cucumber slices if desired.</li>   <li>Chill in the refrigerator for at least 30 minutes.</li>   <li>Serve cold and enjoy Sinuglaw!</li>   </ol>",
  "Please click the button to proceed,"
];

function sinuglawNext(){
   sinuglawIP = (sinuglawIP + 1) % sisinuglaw.length;
  document.getElementById("sinuglawIngproc").innerHTML = sisinuglaw[sinuglawIP];
}

//Kiyonging
let kiyoningIP = 1;
const kikiyoning = [
  "Ingredients:<br><ul>  <li>1 whole chicken, cut into serving pieces</li>   <li>2 cups of coconut milk</li>   <li>1 tablespoon of turmeric powder</li>   <li>1 onion, chopped</li>   <li>3 cloves of garlic, minced</li>   <li>2 stalks of lemongrass, pounded</li>   <li>2 pieces of ginger, sliced</li>   <li> 2 pieces of green chili pepper</li>   <li>Salt and pepper to tast</li>   <li> 2 tablespoons of cooking oil</li>    </ul>",
  "Procedures:<br><ol>  <li>Prepare all the ingredients. Cut the chicken, chop the onion, mince<br> the garlic, pound the lemongrass, and slice the ginger in 15 minutes.</li>   <li>Heat the cooking oil in a pot. Sauté the garlic, onion, and ginger until they<br> become fragrant.</li>   <li>Add the chicken pieces to the pot. Cook until they turn slightly brown.</li>   <li>Add the turmeric powder to the pot. Stir well to coat the chicken with the turmeric.</li>   <li>Add the lemongrass and green chili pepper to the pot. Stir again.</li>   <li>Pour the coconut milk into the pot. Bring the mixture to a boil.</li>   <li>Once boiling, reduce the heat to low. Cover the pot and let it simmer for about 40-45 minutes, or until the chicken is fully cooked<br> and the flavors are well blended.</li>   <li>Season with salt and pepper to taste. Stir well.</li>   <li>Once the chicken is cooked and the soup has thickened to your liking, turn off the heat.</li>  <li>Serve the Kiyoning hot with rice. Enjoy your meal!</li>   </ol>",
  "Please click the button to proceed,"
];

function kiyoningNext(){
kiyoningIP = (kiyoningIP + 1) % kikiyoning.length;
  document.getElementById("kiyoningIngproc").innerHTML = kikiyoning[kiyoningIP];
}

//Kulma
let kulmaIP = 1;
const kukulma = [
  "Ingredients:<br><ul> <li>500g seafood (crab, prawns), cleaned</li>  <li>1 cup coconut milk</li>  <li>1 onion, sliced</li>  <li>2-3 cloves garlic, minced</li>  <li>1 thumb-sized ginger, sliced</li>  <li>2 tablespoons fish sauce (patis)</li>  <li>2 tablespoons cooking oil</li>  <li>Salt and pepper to taste</li>      </ul>",
  "Procedures:<br><ol>  <li>In a pan, heat cooking oil and sauté garlic, ginger, and onion until aromatic.</li>   <li>Add seafood and cook until they change color.</li>  <li>Pour coconut milk and bring to a simmer.</li>   <li>Season with fish sauce, salt, and pepper.</li>   <li>Simmer until the seafood is fully cooked.</li>   <li>Adjust seasoning if necessary.</li>   <li>Serve hot and enjoy Kulma!</li>    </ol>",
  "Please click the button to proceed,"
];

function kulmaNext(){
  kulmaIP = (kulmaIP + 1) % kukulma.length;
  document.getElementById("kulmaIngproc").innerHTML = kukulma[kulmaIP];
}

//Sinina
let sininaIP = 1;
const sasinina = [
  "Ingredients:<br><ul>  <li>1 kg beef, cut into serving pieces</li>   <li>1 kg beef, cut into serving pieces</li>   <li>2 cups coconut milk</li>   <li>2 tablespoons palapa (You can make this by combining 1 cup of sakurab, 1/2 cup<br> of chopped ginger, and 5 pieces of chili pepper, then grinding them into a paste)</li>   <li>1 onion, chopped</li>   <li>3 cloves of garlic, minced</li>   <li>2 pieces of turmeric, sliced</li>   <li>2 pieces of ginger, sliced</li>   <li>2 stalks of lemongrass, pounded</li>   <li>Salt and pepper to taste</li>   <li>2 tablespoons of cooking oil</li>      </ul>",
  "Procedures:<br><ol>  <li>Prepare all the ingredients. Cut the beef, chop the onion, mince the garlic, slice the turmeric<br> and ginger, and pound the lemongrass. Prepare the palapa.</li>   <li>Heat the cooking oil in a pot. Sauté the garlic, onion, ginger, and turmeric<br> until they become fragrant.</li>   <li>Add the beef to the pot. Cook until it turns slightly brown.</li>   <li>Add the palapa to the pot. Stir well to coat the beef with the palapa.</li>   <li>Add the lemongrass to the pot. Stir again.</li>   <li>Pour the coconut milk into the pot. Bring the mixture to a boil.</li>   <li>Once boiling, reduce the heat to low. Cover the pot and let it simmer for about 1 hour<br> to 1 hour 15 minutes, or until the beef is tender and the flavors are well blended.</li>   <li>Season with salt and pepper to taste. Stir well.</li>   <li>Once the beef is tender and the soup has thickened to your liking, turn off the heat.</li>   <li>Serve the Sinina hot with rice. Enjoy your meal!</li>   </ol>",
  "Please click the button to proceed,"
];

function sininaNext(){
sininaIP = (sininaIP + 1) % sasinina.length;
  document.getElementById("sininaIngproc").innerHTML = sasinina[sininaIP];
}










/**MINDANAO SIDE DISHES */

//Linotlot na isda
let linotlotIP = 1;
const lilinotlot = [
  "Ingredients:<br><ul>  <li>500g Fish fillets (tilapia or any white fish)</li>  <li>1 cup Coconut milk</li>  <li>2 tablespoons Ginger, sliced</li>  <li>2 stalks Lemongrass, chopped</li>  <li>1 medium Onion, sliced</li>  <li>1 medium Onion, sliced</li>  <li>2 cloves Garlic, minced</li>  <li>Salt and pepper to taste</li>  <li>Banana leaves for wrapping</li>    </ul>",
  "Procedures:<br><ol>  <li>Clean the fish fillets and pat them dry.</li>  <li>In a bowl, mix coconut milk, ginger, lemongrass, onion, garlic, salt, and pepper.</li>  <li>Place each fish fillet on a piece of banana leaf. Pour the coconut milk<br> mixture over each fillet.</li>  <li>Wrap the fish securely in banana leaves, forming packets.</li>  <li>Steam the wrapped fish for about 20-25 minutes or until the fish is cooked through.</li>  <li>Serve hot and enjoy!</li>     </ol>",
  "Please click the button to proceed,"
];

function linotlotNext(){
  linotlotIP = (linotlotIP + 1) % lilinotlot.length;
  document.getElementById("linotlotIngproc").innerHTML = lilinotlot[linotlotIP];
}


//Tabalang Adobo
let tabalangIP = 1;
const tatabalang = [
  "Ingredients:<br><ul>  <li>500g Tabalang (shellfish)</li>  <li>1/4 cup Soy sauce</li>  <li>1/4 cup Vinegar</li>  <li>3 cloves Garlic, minced</li>  <li>2 Bay leaves</li>  <li>1 teaspoon Peppercorns</li>  <li>2 tablespoons Cooking oil</li>  <li>1 cup Water</li>  <li>Salt and sugar to taste</li>     </ul>",
  "Procedures:<br><ol>  <li>Clean the tabalang thoroughly and set aside.</li>  <li>In a pan, heat oil and sauté garlic<br> until fragrant.</li>  <li>Add tabalang to the pan and cook until slightly browned.</li>  <li>Pour in soy sauce, vinegar, water, bay<br> leaves, peppercorns, salt, and sugar. Simmer until the tabalang is tender.</li>  <li>Continue simmering until the sauce thickens.</li>  <li>Serve hot with steamed rice.</li>    </ol>",
  "Please click the button to proceed,"
];

function tabalangNext(){
  tabalangIP = (tabalangIP + 1) % tatabalang.length;
  document.getElementById("tabalangIngproc").innerHTML = tatabalang[tabalangIP];
}


//Utak-Utak
let utakIP = 1;
const utakutak = [
  "Ingredients:<br><ul>  <li>1 cup Minced fish (tilapia or any white fish)</li>  <li>1/2 cup Coconut milk</li>  <li>3 cloves Garlic, minced</li>  <li>1 medium Onion, minced</li>  <li>1 tablespoon Ginger, minced</li>  <li>Salt and pepper to taste</li>  <li>Banana leaves for wrapping</li>  </ul>",
  "Procedures:<br><ol>  <li>In a bowl, mix minced fish, coconut milk, garlic, onion, ginger, salt, and pepper.</li>  <li>Lay out banana leaves and portion the mixture onto the leaves.</li>  <li>Roll and wrap the mixture tightly in banana leaves, forming cylindrical shapes.</li>  <li>Grill the wrapped utak-utak until the banana leaves are slightly charred,br> and the fish is cooked through.</li>  <li>Serve hot and enjoy!</li>     </ol>",
  "Please click the button to proceed,"
];

function takutakNext(){
  utakIP = (utakIP + 1) % utakutak.length;
  document.getElementById("utakutakIngproc").innerHTML = utakutak[utakIP];
}

//Hinava
let hinavaIP = 1;
const hihinava = [
  "Ingredients:<br><ul>  <li>500g Fresh fish fillets (tuna or any firm white fish), cubed</li>  <li>1/2 cup Calamansi juice</li>  <li>2 tablespoons Ginger, grated</li>  <li>1 Red onion, thinly sliced</li>  <li>2 Bird's eye chili (labuyo), chopped</li>  <li>Salt and pepper to taste</li>  <li>Cucumber, sliced - for garnish</li>  <li>Green mango, sliced - for garnish</li>     </ul>",
  "Procedures:<br><ol>  <li>In a bowl, combine fish fillets, calamansi juice, ginger, red onion, bird's eye<br> chili, salt, and pepper.</li>  <li>Mix well and let it marinate for at least 30 minutes.</li>  <li>Garnish with sliced cucumber and green mango.</li>  <li>Serve chilled and enjoy this refreshing dish!</li>     </ol>",
  "Please click the button to proceed,"
];

function hinavaNext(){
  hinavaIP = (hinavaIP + 1) % hihinava.length;
  document.getElementById("hinavaIngproc").innerHTML = hihinava[hinavaIP];
}

//Lawar
let lawarIP = 1;
const lilawar = [
  "Ingredients:<br><ul>  <li>1 cup Minced pork or chicken</li>  <li>1 cup Grated coconut</li>  <li>2 stalks Lemongrass, chopped</li>  <li>1 tablespoon Galangal, minced</li>  <li>3 Kaffir lime leaves, finely chopped</li>  <li>3 Shallots, minced</li>  <li>2 cloves Garlic, minced</li>  <li>1 Red chili, chopped</li>  <li> 2 tablespoons Fish sauce</li>  <li>Salt and pepper to taste</li>    </ul>",
  "Procedures:<br><ol>  <li>In a pan, cook minced pork or chicken until browned.</li>  <li>Add lemongrass, galangal, kaffir lime leaves, shallots, garlic, and red<br> chili. Cook until fragrant.</li>  <li>Add grated coconut and continue cooking until coconut is slightly toasted.</li>  <li>Season with fish sauce, lime juice, salt, and pepper. Mix well.</li>  <li>Serve warm and enjoy this flavorful dish!</li>    </ol>",
  "Please click the button to proceed,"
];

function lawarNext(){
  lawarIP = (lawarIP + 1) % lilawar.length;
  document.getElementById("lawarIngproc").innerHTML = lilawar[lawarIP];
}








/**MINDANAO DESSERTS */ 

//Durian Candy
let durianIP = 1;
const durianCandy = [
   "Ingredients:<br><ul>  <li>2 cups durian flesh, mashed</li>  <li>1 cup sugar</li>   <li>1/2 cup water</li>   <li>Wax paper for wrapping</li>        </ul>",
   "Procedures:<br><ol>  <li>In a saucepan, combine mashed durian flesh, sugar, and water.</li>  <li>Cook over medium heat, stirring continuously until the mixture thickens and becomes sticky.</li>   <li>Once the mixture reaches a caramel-like consistency, remove from heat.</li>   <li>Allow it to cool slightly, then scoop spoonfuls of the mixture and roll them into small balls<br>or shape them as desired.</li>   <li>Wrap each piece in wax paper to prevent sticking.</li>   <li>Let the durian candies cool completely before serving.</li>        </ol>",
   "Please click the button to proceed,"

  ];

function durianNext(){
  durianIP = (durianIP + 1) % durianCandy.length;
  document.getElementById("durianCandyIngproc").innerHTML = durianCandy[durianIP];
}

//Tinagtag
let tinagtagIP = 1;
const titinagtag = [
   "Ingredients:<br><ul>  <li>2 cups glutinous rice flour</li>  <li>1 cup ripe saba bananas, mashed</li>   <li>1/2 cup brown sugar</li>   <li>Oil for frying</li>       </ul>",
   "Procedures:<br><ol>  <li>In a bowl, combine glutinous rice flour, mashed bananas, and brown sugar. Mix until a dough-<br>like consistency is achieved.</li>  <li>Take small portions of the mixture and shape them into cylindrical or round pieces.</li>   <li> Heat oil in a pan for frying.</li>   <li>Fry the shaped dough pieces until golden brown.</li>   <li>Remove from oil, drain excess oil, and let them cool before serving.</li>       </ol>",
   "Please click the button to proceed,"

  ];

function tinagtagNext(){
  tinagtagIP = (tinagtagIP + 1) % titinagtag.length;
  document.getElementById("tinagtagIngproc").innerHTML = titinagtag[tinagtagIP];
}

//Suman sa Lihiya
let sumanIP = 1;
const susumanLihiya = [
   "Ingredients:<br><ul>  <li>2 cups glutinous rice</li>  <li>1 teaspoon lihiya (lye water)</li>   <li>Banana leaves, cleaned and cut into squares</li>   <li>Coconut strips for garnish</li>      </ul>",
   "Procedures:<br><ol>  <li>Rinse glutinous rice and soak it in water for a few hours.</li>  <li>Drain the rice and mix in lihiya until well-distributed.</li>   <li>Take a portion of the mixture and wrap it in banana leaves, forming cylindrical shapes.</li>   <li>Steam the suman until cooked through.</li>   <li>Serve with coconut strips on top.</li>       </ol>",
   "Please click the button to proceed,"

  ];

function lihiyaNext(){
   sumanIP= (sumanIP + 1) % susumanLihiya.length;
  document.getElementById("LihiyaIngproc").innerHTML = susumanLihiya[sumanIP];
}

//Pisang Goreng
let gorengIP = 1;
const gogorereng = [
   "Ingredients:<br><ul>  <li>Ripe bananas, sliced</li>  <li> 1 cup all-purpose flour</li>   <li>1/4 cup rice flour</li>   <li>1/2 teaspoon baking powder</li>   <li>1/4 teaspoon salt</li>   <li>1 cup water</li>   <li>Oil for frying</li>         </ul>",
   "Procedures:<br><ol>  <li>In a bowl, mix all-purpose flour, rice flour, baking,<br> powder, salt, and water to create a smooth batter.</li>  <li>Dip banana slices into the batter, ensuring they are well-coated.</li>   <li>Heat oil in a pan for frying.</li>   <li>Fry the banana slices until golden brown.</li>   <li>Remove from oil, drain excess oil, and let them cool before serving.</li>       </ol>",
   "Please click the button to proceed,"

  ];

function gorengNext(){
  gorengIP = (gorengIP + 1) % gogorereng.length;
  document.getElementById("gorengIngproc").innerHTML = gogorereng[gorengIP];
}


//Tahuri
let tahuriIP = 1;
const  tahruri = [
   "Ingredients:<br><ul>  <li>1 cup ground peanuts or sesame seeds</li>  <li>1 cup sugar</li>   <li>1/2 cup rice flour (optional, for binding)</li>   <li>Water (as needed)</li>       </ul>",
   "Procedures:<br><ol>  <li>In a bowl, mix ground peanuts or sesame seeds with sugar.</li>  <li>Gradually add water and mix until you achieve a thick paste-like consistency.</li>   <li>If desired, add rice flour to bind the mixture further.</li>   <li> Shape the mixture into small bite-sized pieces.</li>        </ol>",
   "Please click the button to proceed,"

  ];

function tahuriNext(){
  tahuriIP = (tahuriIP + 1) % tahruri.length;
  document.getElementById("tahuriIngproc").innerHTML = tahruri[tahuriIP];
}
